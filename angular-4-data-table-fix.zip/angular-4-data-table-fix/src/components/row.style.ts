export const ROW_STYLE = `
.select-column {
    text-align: center;
}

.row-expand-button {
    cursor: pointer;
    text-align: center;
}

.clickable {
    cursor: pointer;
}
`;